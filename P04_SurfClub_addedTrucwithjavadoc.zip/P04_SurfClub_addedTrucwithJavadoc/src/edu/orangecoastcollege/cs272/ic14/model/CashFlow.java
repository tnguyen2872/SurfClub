package edu.orangecoastcollege.cs272.ic14.model;

public class CashFlow {
	private int mID;
	private String mYear;
	private String mMonth;
	private double mRent;
	private double mWage;
	private double mSupply;
	private double mTax;
	private double mTotal;
	private double mSale;
	private double mProfit;
	
	/**
	 * Constructor for CashFlow
	 * 
	 * @param mID
	 * @param mYear
	 * @param mMonth
	 * @param mRent
	 * @param mWage
	 * @param mSupply
	 * @param mTax
	 * @param mTotal
	 * @param mSale
	 * @param mProfit
	 */
	
	public CashFlow(int mID, String mYear, String mMonth, double mRent, double mWage, double mSupply, double mTax,
			double mTotal, double mSale, double mProfit) {
		super();
		this.mID = mID;
		this.mYear = mYear;
		this.mMonth = mMonth;
		this.mRent = mRent;
		this.mWage = mWage;
		this.mSupply = mSupply;
		this.mTax = mTax;
		this.mTotal = mTotal;
		this.mSale = mSale;
		this.mProfit = mProfit;
	}
	
	/**
	 * Gets the current value assigned to mId
	 * @return mID
	 */
	
	public int getmID() {
		return mID;
	}


	/**
	 * Sets a new value to mId
	 * @param mID
	 */
	public void setmID(int mID) {
		this.mID = mID;
	}


	/**
	 * Returns the current value assigned to mYear
	 * @return mYear
	 */
	public String getmYear() {
		return mYear;
	}


	/**
	 * Sets a new year to mYear
	 * @param mYear
	 */
	public void setmYear(String mYear) {
		this.mYear = mYear;
	}


	/**
	 * Returns the current mMonth
	 * @return mMonth
	 */
	public String getmMonth() {
		return mMonth;
	}


	/**
	 * Sets a new month to nMonth
	 * @param mMonth
	 */
	public void setmMonth(String mMonth) {
		this.mMonth = mMonth;
	}

	/**
	 * Returns the current mRent
	 * @return mRent
	 */

	public double getmRent() {
		return mRent;
	}

	/**
	 * Sets a new value to mRent
	 * @param mRent
	 */
	public void setmRent(double mRent) {
		this.mRent = mRent;
	}

	/**
	 * Returns current Wage
	 * @return mWage
	 */
	public double getmWage() {
		return mWage;
	}

	/**
	 * Sets a new value to mWage
	 * @param mWage
	 */
	public void setmWage(double mWage) {
		this.mWage = mWage;
	}

	/**
	 * Returns the current Supply
	 * @return mSupply
	 */
	public double getmSupply() {
		return mSupply;
	}
	
	/**
	 * Sets a new value for mSupply
	 * @param mSupply
	 */
	public void setmSupply(double mSupply) {
		this.mSupply = mSupply;
	}


	/**
	 * Returns the current Tax value
	 * @return mTax
	 */
	public double getmTax() {
		return mTax;
	}

	/**
	 * Sets a new value for mTax
	 * @param mTax
	 */
	public void setmTax(double mTax) {
		this.mTax = mTax;
	}

	/**
	 * Returns the current Total
	 * @return mTotal
	 */
	public double getmTotal() {
		return mTotal;
	}

	/**
	 * Sets a new value for mTotal
	 * @param mTotal
	 */
	public void setmTotal(double mTotal) {
		this.mTotal = mTotal;
	}

	/**
	 * Returns the current Sale
	 * @return mSale
	 */
	public double getmSale() {
		return mSale;
	}


	/**
	 * Sets a new value to mSale
	 * @param mSale
	 */
	public void setmSale(double mSale) {
		this.mSale = mSale;
	}


	/**
	 * Returns the current Profit
	 * @return mProfit
	 */
	public double getmProfit() {
		return mProfit;
	}

	/**
	 * Sets a new value to mProfit
	 * @param mProfit
	 */
	public void setmProfit(double mProfit) {
		this.mProfit = mProfit;
	}

	
	/**
	 * This the overloaded shashcode function
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + mID;
		result = prime * result + ((mMonth == null) ? 0 : mMonth.hashCode());
		long temp;
		temp = Double.doubleToLongBits(mProfit);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(mRent);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(mSale);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(mSupply);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(mTax);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(mTotal);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(mWage);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((mYear == null) ? 0 : mYear.hashCode());
		return result;
	}

	
	/**
	 * This the overloaded equals function
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CashFlow other = (CashFlow) obj;
		if (mID != other.mID)
			return false;
		if (mMonth == null) {
			if (other.mMonth != null)
				return false;
		} else if (!mMonth.equals(other.mMonth))
			return false;
		if (Double.doubleToLongBits(mProfit) != Double.doubleToLongBits(other.mProfit))
			return false;
		if (Double.doubleToLongBits(mRent) != Double.doubleToLongBits(other.mRent))
			return false;
		if (Double.doubleToLongBits(mSale) != Double.doubleToLongBits(other.mSale))
			return false;
		if (Double.doubleToLongBits(mSupply) != Double.doubleToLongBits(other.mSupply))
			return false;
		if (Double.doubleToLongBits(mTax) != Double.doubleToLongBits(other.mTax))
			return false;
		if (Double.doubleToLongBits(mTotal) != Double.doubleToLongBits(other.mTotal))
			return false;
		if (Double.doubleToLongBits(mWage) != Double.doubleToLongBits(other.mWage))
			return false;
		if (mYear == null) {
			if (other.mYear != null)
				return false;
		} else if (!mYear.equals(other.mYear))
			return false;
		return true;
	}

	
	/**
	 * Outputs the a String in of CashFlow in a formatted form
	 */
	@Override
	public String toString() {
		return "CashFlow [Year=" + mYear + ", Month=" + mMonth + ", Rent=" + mRent + "$, Wages Payable=" + mWage
				+ "$, Supplies=" + mSupply + "$, Tax=" + mTax + "$, Total Expenses=" + mTotal + "$, Sale=" + mSale + "$, Profit="
				+ mProfit + "$]";
	}
	
	
	

}
